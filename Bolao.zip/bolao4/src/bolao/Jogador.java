package bolao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Jogador extends Pessoa {
    String pix;

    Jogador(ArrayList<Jogador> j) {
        super(j);

        boolean continua;

        Scanner s = new Scanner(System.in);

        System.out.println("Digite o pix do jogador: ");
        continua = true;
        while (continua) {
            this.pix = s.nextLine();

            if (this.pix.equals("") || this.pix.equals(" ")) {
                System.out.println("PIX inválido! Tente novamente.");
            } else {
                continua = false;
            }

            for (Jogador pessoa : j) {
                if (pessoa.pix.equals(this.pix)) {
                    System.out.println("PIX inválido! Tente novamente.");
                    continua = true;
                }
            }
        }
    }

    public Jogador(BufferedReader b) throws IOException{
        super(b);
        this.pix = b.readLine();
    }

    public void listarDados() {
        super.listarDados();
        System.out.println("PIX: " + this.pix);
    }

    public void salvarArquivo(BufferedWriter b) throws IOException {
        b.write(this.nome + "\n");
        b.write(this.cpf + "\n");
        b.write(this.pix + "\n");
    }
}
