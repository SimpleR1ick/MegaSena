package bolao;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class Aposta {
    ArrayList<Integer> numeros;
    Jogador organizador;
    ArrayList<Jogador> jogadores;

    Aposta() {
        numeros = new ArrayList<>();
        jogadores = new ArrayList<>();
    }
    boolean vencedor(ArrayList<Integer> nums) {
        int cont = 0;
        for (int i=0; i<6; i++) {
            for (Integer numero : this.numeros) {
                if (numero.equals(nums.get(i))) {
                    cont++;
                }
            }
        }
        return cont >= 6;
    }
    void listarVencedores(double valor) {
        int cont;

        double valorOrg = (valor * 0.1) + (valor - valor * 0.1)/(this.jogadores.size() + 1);
        double valorJog = (valor - valor * 0.1)/(this.jogadores.size() + 1);

        ArrayList<Jogador> jogadoresN = new ArrayList<>();

        for (Jogador jogador : this.jogadores) {
            if (!jogadoresN.contains(jogador)) {
                jogadoresN.add(jogador);
            }
        }
        System.out.println("Vencedores:");
        this.organizador.listarDados();
        System.out.format("Prêmio: %.2f \n", valorOrg);

        for (Jogador jog : jogadoresN) {
            cont = 0;

            for (Jogador j : this.jogadores) {
                if (jog.equals(j)) {
                    cont++;
                }
            }
            if (!jog.cpf.equals(this.organizador.cpf)) {
                jog.listarDados();
                System.out.format("Prêmio: %.2f \n", (valorJog * cont));
            }
        }
    }

    void inserirNumeros() {
        int q = 0;
        int num;
        boolean continua;

        Scanner s = new Scanner(System.in);

        System.out.println("Insira a quantidade de números apostados, entre 6 e 15: ");
        continua = true;
        while (continua) {
            try {
                q = s.nextInt();

                while (q < 6 || q > 15) {
                    System.out.println("Essa não é uma quantia válida, tente novamente.");
                    q = s.nextInt();
                }
                continua = false;
            }
            catch (InputMismatchException e) {
                System.out.println("Quantidade inválida! Tente novamente.");
                s.nextLine();
            }
        }
        System.out.println("Insira os números apostados: ");
        continua = true;
        while (continua) {
            try {
                while (this.numeros.size() < q) {
                    num = s.nextInt();
                    if (num >= 1 && num <= 60) {
                        if (!this.numeros.contains(num)) {
                            this.numeros.add(num);
                        } else {
                            System.out.println("Esse não é um número válido");
                        }
                    } else {
                        System.out.println("Esse não é um número válido");
                    }
                }
                continua = false;
            }
            catch (InputMismatchException e) {
                System.out.println("Número inválido! Tente novamente.");
                s.nextLine();
            }
        }
    }
    void inserirOrganizador(ArrayList<Jogador> jogadores) {
        int l;
        int i = 1;
        String cpf;
        boolean continua = true;

        Scanner s = new Scanner(System.in);

        System.out.println("Escolha um jogador para ser o organizador digitando o seu cpf.");
        for (Jogador jogador : jogadores) {
            System.out.println(i + ") " + jogador.cpf + " - " + jogador.nome);
            i++;
        }
        while (continua) {
            l = 0;
            cpf = s.nextLine();

            for (Jogador jogador : jogadores) {
                if (jogador.cpf.equals(cpf)) {
                    this.organizador = jogador;
                    continua = false;
                } else {
                    l++;
                }
            }
            if (l == jogadores.size()) {
                System.out.println("Organizador inválido! Tente novamente.");
            }
        }
    }

    void inserirJogadores(ArrayList<Jogador> jogadoresN) {
        int k;
        int l;
        int j = 0;
        String cpf;
        boolean faca;
        boolean continua = true;

        Scanner s = new Scanner(System.in);

        System.out.println("Insira a quantidade de jogadores que apostarão no bilhete: ");
        while (continua) {
            try {
                j = Integer.parseInt(s.nextLine());

                while (j <= 0) {
                    System.out.println("Quantidade inválida! Tente novamente!");
                    j = Integer.parseInt(s.nextLine());
                }
                continua = false;
            }
            catch (NumberFormatException e) {
                System.out.println("Quantidade inválida! Tente novamente.");
            }
        }

        for (int i=1; i<=j; i++) {
            faca = true;

            while (faca) {
                k = 1;
                System.out.println("Digite os jogadores que participarão digitando o seu cpf.");
                for (Jogador jogador : jogadoresN) {
                    if (!jogador.cpf.equals(this.organizador.cpf)) {
                        System.out.println(k + ") " + jogador.cpf + " - " + jogador.nome);
                        k++;
                    }
                }
                l = 0;
                cpf = s.nextLine();

                for (Jogador jogador : jogadoresN) {

                    if (jogador.cpf.equals(cpf)) {
                        if (!jogador.cpf.equals(this.organizador.cpf)) {
                            this.jogadores.add(jogador);
                            faca = false;
                        } else {
                            l++;
                        }
                    } else {
                        l++;
                    }
                }
                if (l == jogadoresN.size()) {
                    System.out.println("Jogador inválido! Tente novamente.\n");
                }
            }
        }
    }
}
