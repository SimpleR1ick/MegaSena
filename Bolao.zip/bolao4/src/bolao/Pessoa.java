package bolao;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Pessoa {
    String nome;
    String cpf;

    public Pessoa(ArrayList<Jogador> j) {
        boolean continua;

        Scanner s = new Scanner(System.in);

        System.out.println("Digite o nome: ");
        continua = true;
        while (continua) {
            this.nome = s.nextLine();

            if (this.nome.equals("") || this.nome.equals(" ")) {
                System.out.println("Nome inválido! Tente novamente.");
            } else {
                continua = false;
            }
        }
        System.out.println("Digite o CPF: ");
        continua = true;
        while (continua) {
            this.cpf = s.nextLine();

            if (this.cpf.equals("") || this.cpf.equals(" ")) {
                System.out.println("CPF inválido! Tente novamente.");
            } else {
                continua = false;
            }

            for (Jogador pessoa : j) {
                if (pessoa.cpf.equals(this.cpf)) {
                    System.out.println("CPF inválido! Tente novamente.");
                    continua = true;
                }
            }
        }
    }
    public Pessoa(BufferedReader b) throws IOException {
        this.nome = b.readLine();
        this.cpf = b.readLine();
    }

    void listarDados() {
        System.out.println("Nome: " + this.nome);
        System.out.println("CPF: " + this.cpf);
    }
}
