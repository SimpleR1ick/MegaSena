package bolao;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class Sistema {
    ArrayList<Aposta> apostas;
    ArrayList<Jogador> jogadores;

    Sistema() {
        apostas = new ArrayList<>();
        jogadores = new ArrayList<>();

        this.lerJogadoresArquivo();
    }

    static int menuInicial() {
        int op = 0;
        boolean continua = true;

        Scanner s = new Scanner(System.in);

        System.out.println("Bem Vindo! Escolha uma opção\n");
        System.out.println("1) Cadastrar Jogador");
        System.out.println("2) Cadastrar Aposta");
        System.out.println("3) Inserir sorteio e listar vencedores");
        System.out.println("4) Sair\n");

        while (continua) {
            try {
                op = s.nextInt();
                continua = false;
            }
            catch (InputMismatchException e) {
                System.out.println("Opção inválida! Tente novamente.");
                s.nextLine();
            }
        }

        return op;
    }

    static void cadastro(Sistema s) {
        int op = menuInicial();

        while (op != 4) {
            if (op == 1) {
                s.cadastrarJogador();
                s.salvarJogadoresArq();
            }
            if (op == 2) {
                s.cadastrarAposta();
            }
            if (op == 3) {
                s.inserirSorteio();
            }
            op = menuInicial();
        }
    }

    void cadastrarJogador() {
        Jogador j = new Jogador(this.jogadores);

        this.jogadores.add(j);
    }

    void cadastrarAposta() {
        if (this.jogadores.size() > 1) {
            Aposta a = new Aposta();

            a.inserirOrganizador(this.jogadores);
            a.inserirJogadores(this.jogadores);
            a.inserirNumeros();

            this.apostas.add(a);

        } else {
            System.out.println("É necessário ter mais jogadores para cadastrar uma aposta.\n");
        }
    }

    void inserirSorteio() {
        if (this.apostas.size() != 0) {
            double premio = 0;
            boolean continua;
            boolean faca = true;
            ArrayList<Integer> sorteados;
            ArrayList<Aposta> premiadas;

            sorteados = new ArrayList<>();

            Scanner s = new Scanner(System.in);

            System.out.println("Digite os números sorteados: ");
            for (int i=0; i<6; i++) {
                continua = true;
                while (continua) {
                    try {
                        sorteados.add(s.nextInt());
                        continua = false;
                    }
                    catch (InputMismatchException e) {
                        System.out.println("Número inválido! Tente novamente.");
                        s.nextLine();
                    }
                }
            }

            System.out.println("Digite o valor do prêmio desse bilhete: ");
            while (faca) {
                try {
                    premio = s.nextDouble();
                    faca = false;
                }
                catch (InputMismatchException e) {
                    System.out.println("Prêmio inválido! Tente novamente.");
                    s.nextLine();
                }
            }

            premiadas = vencedoras(sorteados);

            premio = premio / premiadas.size();

            for (Aposta a : premiadas) {
                a.listarVencedores(premio);
            }
        } else {
            System.out.println("É necessário ter mais apostas para cadastrar uma sorteio.\n");
        }
    }

    private ArrayList<Aposta> vencedoras(ArrayList<Integer> sorteados) {
        ArrayList<Aposta> premiadas;

        premiadas = new ArrayList<>();

        for (Aposta a : this.apostas) {
            if (a.vencedor(sorteados)) {
                premiadas.add(a);
            }
        }
        return premiadas;
    }

    public void lerJogadoresArquivo() {
        try {
            FileReader f = new FileReader("jogadores.txt");
            BufferedReader b = new BufferedReader(f);

            int l = Integer.parseInt(b.readLine());

            for (int i=0; i<l; i++) {
                this.jogadores.add(new Jogador(b));
            }

            b.close();
            System.out.println(this.jogadores.size() + " jogadores carregados.");
        }
        catch (NumberFormatException | IOException e) {
            this.jogadores = new ArrayList<>();
            System.out.println("Nenhum jogador carregado.");
        }
    }

    public void salvarJogadoresArq() {
        try {
            FileWriter f = new FileWriter("jogadores.txt");
            BufferedWriter b = new BufferedWriter(f);

            b.write(this.jogadores.size() + "\n");

            for (Jogador j : this.jogadores) {
                j.salvarArquivo(b);
            }

            b.close();
        }
        catch (IOException e) {
            System.out.println("Erro ao salvar o arquivo.");
        }
    }

    public static void main(String[] args) {
        Sistema s = new Sistema();
        cadastro(s);
    }
}
